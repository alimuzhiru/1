<?php


namespace App\Traits;


trait HasWallet
{
    use \Bavix\Wallet\Traits\HasWallet;


}
