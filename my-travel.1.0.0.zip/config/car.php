<?php
return [
    'car_route_prefix' => env("CAR_ROUTER_PREFIX","car"),
];