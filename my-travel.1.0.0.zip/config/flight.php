<?php
return [
    'flight_route_prefix' => env("FLIGHT_ROUTE_PREFIX","flight"),
];