<?php
return [
    'hotel_route_prefix' => env("HOTEL_ROUTER_PREFIX","hotel"),
];