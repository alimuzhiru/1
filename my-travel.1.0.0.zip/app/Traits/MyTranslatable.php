<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 7/16/2019
 * Time: 4:52 PM
 */
namespace App\Traits;

use Astrotomic\Translatable\Translatable;

Trait MyTranslatable{

    use Translatable;

    public function translateOrOrigin(){

    }
}